import express from "express";
import { requireAuth } from "../middleware/auth.js";
import { callClaude } from "../utils/claude.js";

const router = express.Router();

const SYSTEM_PROMPT = "You are a friendly, knowledgeable dog care assistant inside the PawDiagnose AI app. Answer questions about nutrition, vaccination schedules, deworming, grooming, puppy care, and general canine health in a clear, concise, warm tone. Always make clear you provide general educational information, not a diagnosis, and recommend a licensed veterinarian for specific medical concerns.";

router.post("/", requireAuth, async (req, res) => {
  try {
    const { messages } = req.body || {};
    if (!Array.isArray(messages) || !messages.length) {
      return res.status(400).json({ error: "No message provided." });
    }
    const apiMessages = messages.map((m) => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: m.text
    }));
    const text = await callClaude(apiMessages, { system: SYSTEM_PROMPT });
    res.json({ text });
  } catch (e) {
    console.error("chat error:", e);
    res.status(500).json({ error: e.message || "Sorry, something went wrong reaching the assistant." });
  }
});

export default router;
