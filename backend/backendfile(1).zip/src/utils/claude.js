// Server-side Anthropic API client.
// The API key stays here and is never exposed to the browser.

const MODEL = "claude-sonnet-4-6";

export async function callClaude(messages, { system, maxTokens = 1000 } = {}) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey || apiKey.includes("your-key-here")) {
    throw new Error("The server is missing a valid ANTHROPIC_API_KEY. Add one to backend/.env and restart the server.");
  }

  const body = { model: MODEL, max_tokens: maxTokens, messages };
  if (system) body.system = system;

  let res;
  try {
    res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify(body)
    });
  } catch (netErr) {
    throw new Error("Network error reaching Anthropic: " + netErr.message);
  }

  let data;
  try {
    data = await res.json();
  } catch {
    throw new Error("Anthropic returned an unreadable response (status " + res.status + ").");
  }

  if (!res.ok || data.error) {
    const msg = (data && data.error && data.error.message) || `Anthropic API request failed with status ${res.status}`;
    throw new Error(msg);
  }

  const text = (data.content || [])
    .map((b) => (b.type === "text" ? b.text : ""))
    .filter(Boolean)
    .join("\n");

  if (!text) throw new Error("Anthropic returned an empty response.");
  return text;
}

export function extractJson(raw) {
  if (!raw) return null;
  let cleaned = raw.replace(/```json/gi, "").replace(/```/g, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start !== -1 && end !== -1) cleaned = cleaned.slice(start, end + 1);
  try {
    return JSON.parse(cleaned);
  } catch {
    return null;
  }
}
